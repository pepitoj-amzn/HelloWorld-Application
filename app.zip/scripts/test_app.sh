#!/bin/bash
python /home/ec2-user/helloWorld.py > /home/ec2-user/output