import os

def main():
    os.system("echo Yuh Yeet")
    print("Hello World")
    return None

if __name__ == "__main__":
    main()